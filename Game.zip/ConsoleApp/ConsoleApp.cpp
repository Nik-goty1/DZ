#include <iostream>
#include <string>

#include "Public/Scene.h"
#include "Public/Actors/Character.h"

using namespace std;

int main()
{
  Scene scene;
  
  Item sword("Steel Sword");
  Item axe("Vibranium Battle Axe");
  Item food("Mivina");

  Character FallenGod("Fallen God", &scene);

  FallenGod.getInventory().addItem(&sword);
  FallenGod.getInventory().addItem(&axe);
  FallenGod.getInventory().addItem(&food, 5);

  FallenGod.showInventory();
  cout << endl;

  FallenGod.dropItem("Steel Sword");
  cout << endl;
  FallenGod.showInventory();
  cout << endl;
  scene.getActors();
  cout << endl;

  FallenGod.pickUpItem("Steel Sword");
  cout << endl;
  FallenGod.showInventory();
  cout << endl;
  scene.getActors();

  return 0;
}
